const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const path = require('path');
const mysql = require('mysql2')

const router = express()


router.set('view engine', 'ejs')
router.set('views', path.join(__dirname, 'views'))
router.set('views', './views');
router.use(expressLayouts)
router.use('/css', express.static(path.resolve(__dirname, "public/css")));
router.use('/img', express.static(path.resolve(__dirname, "public/img")));


router.get('/login', function (req, res) {
  res.render('login',{
    title:'login',
    layout:'layouts/auth-layout'
  })
})

router.get('/register', function (req, res) {
  res.render('register',{
    title:'register',
    layout:'layouts/auth-layout'
  })
})

router.get('/', function (req, res) {
  res.render('index',{
    title:'dashboard',
    layout:'layouts/main-layout'
  })
})

router.get('/add-form', function (req, res) {
  res.render('add-form',{
    title:'add form',
    layout:'layouts/main-layout'
  })
})

router.get('/profil', function (req, res) {
  res.render('profil',{
    title:'profil',
    layout:'layouts/main-layout'
  })
})






router.listen(3000,(req, res) => {
  console.log('listening on port 3000')
})